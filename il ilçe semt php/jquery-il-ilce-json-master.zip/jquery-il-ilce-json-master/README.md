# jQuery ile dinamik il ilçe uygulaması
JSON dosyasından jQuery ile veri çekerek dinamik il ilçe uygulaması yapmak.
Konu linki için  [buraya](http://www.onlineogren.com/json-ve-jquery-ile-dinamik-il-ilce-uygulamasi.html) tıklayın.