# databases
Araç marka / model veritabanı, meslekler veritabanı, ülkeler iller ve ilçeler veritabanı.
