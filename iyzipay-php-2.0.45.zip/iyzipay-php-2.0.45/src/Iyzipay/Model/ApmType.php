<?php

namespace Iyzipay\Model;

class ApmType
{
    const SOFORT = "SOFORT";
    const IDEAL = "IDEAL";
    const QIWI = "QIWI";
    const GIROPAY = "GIROPAY";
}